=== Page Builder by AZEXO ===
Contributors: azexo
Tags: visual editor, grid builder, slider builder, wysiwyg, website builder, landing page builder, front-end builder, drag-and-drop, builder, editor, azexo, landing page, page builder, form builder, form, carousel, masonry, gallery, hover effects, table, parallax
Requires at least: 4.4
Tested up to: 5.0
Stable tag: 1.27
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Frontend page builder with HTML source editing possibility.


== Description ==

Frontend page builder with HTML source editing possibility.

**[Plugin Demo](http://azexo.com/automation/)**
**[Demo Videos](https://www.youtube.com/playlist?list=PLgb-qaKNfugFNm2gRvl1CsSinlMqRN4cH)**

= Addons =

- **[Elastik elements and sections](https://wordpress.org/plugins/elastik-page-builder/)** - free version. [Preview](http://azexo.com/elastic/)
- **[Mynx elements and sections](https://wordpress.org/plugins/mynx-page-builder/)** - free version. [Preview](http://azexo.com/mynx/)
- **[Form Builder](https://wordpress.org/plugins/cost-calculator-by-azexo/)** - with flexible cost calculator builder
- **[Popup Builder](https://wordpress.org/plugins/popup-builder-by-azexo/)** - building in frontend (useful for high quality complex designs)
- **[Marketing Automation](https://wordpress.org/plugins/marketing-automation-by-azexo/)** - drip marketing, abandoned cart, autoresponder and many more


= Main features =

- CSS styles - fast editing.
- Responsive design - fast editing.
- Unlimited nested layouts.
- Parallax background.
- Video background.
- Gradient background.
- Shape dividers.
- Layered overlays.
- WordPress Widgets - supported.
- Any masonry grid layouts - fast building.
- Any slider layouts - fast building.
- Contact form - fast building with any layout.
- Anchors menu - fast building.
- Sticky header - fast building with any layout.
- Classic table - fast building with any contents.
- Hover overlay - fast building with any layout and with animations.
- Modal dialog - fast building with any layout.
- Scroll animation - simple and flexible.
- Blank Page Template - with header and footer possibility.
- Integrated with Elementor page builder plugin
- Integrated with WPBakery page builder plugin (Visual Composer)


= Works with any theme =

Page Builder by AZEXO is a stand alone plugin that is compatible with any theme, and can be used to create beautiful and fluid layouts inside content areas of any size and shape.


= Pixel Perfect Design in WordPress = 

Page Builder by AZEXO complete design platform to offer pixel perfect design, yet produces 100% clean code. Take your design vision and turn it into a stunning custom-made website.


= Get More Traffic, Leads & Conversions =

Design forms visually with Page Builder by AZEXO, integrate them with your favorite marketing tools, and generate more traffic, leads & conversions.


= SEO Friendly = 

Page Builder by AZEXO is fully compatible with most popular SEO plugins by Yoast. Make sure your page is getting the attention it deserves!


= Create Beautiful, Classy and Pro Websites =

When you have the perfect tool in hand, you can go beyond your imagination. Page Builder by AZEXO is such a web page composer plugin that empowers you to create a great website easily. Seeing the result, you’ll just say “WOW!”. There are lots of design elements such as built-in page layouts, shape dividers, design blocks and many more inside Page Builder by AZEXO. You can build a classy professional website with this tool that can attract the maximum number of visitors.


= Full Width and Height Rows =

Create full width and height rows with smart stretching options with Page Builder by AZEXO. Control stretching params – stretch just the background, or background with content. Control element placement – in the middle or on top. Build sections in seconds.


= Super Fast Site development =

Page Builder by AZEXO is so lightweight, thus takes remarkably less time than all other counterpart tools to create a stunning and functional site. The plugin is well-coded in order to ensure as less run-time as possible. Therefore, it takes almost no time for a command to be executed while building web pages with it.

	
= Video Background = 

Insert YouTube videos into row backgrounds to create dynamic and visually appealing effects. Combine YouTube video background with Page Builder by AZEXO parallax effect.


= Design Your Website Independently =

You don’t need to hire any designer or developer to build professional websites. You can do it all by yourself. It saves you lot of money and time at the same time. Just use all available elements of Page Builder by AZEXO and capitalize the functionalities.


= Gutenberg Compatible =

Page Builder by AZEXO is fully compatible with the Gutenberg editor. Mix your layouts from Page Builder by AZEXO with Gutenberg blocks hassle free.


= Drag & Drop Real-time Editing =

Page Builder by AZEXO enables you to edit your website on the frontend and see the output in real-time. You can use the ready-to-use elements, create simple to complex layouts, and bring different styles to a website in minutes. It’s superbly easy to create and design pages or edit existing ones with this WordPress page builder’s drag and drop system.


= Absolutely No Coding Required =

When you have Page Builder by AZEXO, there is no need to write a single line of code. Any functionality or design you imagine, can be brought to your site with this rich website builder. The drag-and-drop site building system of this WordPress page builder relieves you from writing codes because the required instruments are provided built-in. Just explore and build!


= Perfect for any Level of Users =

Anyone having a little familiarity with WordPress can build a full-fledged website easily with Page Builder by AZEXO. Weather you are just starting out with WordPress or an experienced professional developer, Page Builder by AZEXO comes in handy for everyone’s case with all necessary functionalities.


= Responsive and Mobile-optimized Pages =

Layouts built with this web page builder plugin will fit into all sizes of devices. No matter how many rows and columns you take on a single page, it will have no issues with responsiveness. Page Builder by AZEXO ensures 100% responsive layouts and eye-catching look at the same time. Using the device-specific responsiveness controls, you can render the pages as on different devices (computers, tablets, mobile phones) while editing, and make necessary changes for the perfect responsiveness.


= Customize Font Styles and Colors =

Style your website’s typography and modify the colors easily with Page Builder by AZEXO. Plenty of IcoFont and Font Awesome font icons are available to use with this WordPress page composer plugin. You can utilize any of the 340+ IcoFont line icons and 670+ Font Awesome icons on your site.


= Built-in Blocks =

Page Builder by AZEXO not only helps you build and edit web pages easily, but also lets you use many predefined section elements. There’s a wide variety of readymade section elements in this web page builder to accelerate your site building process. Save time in designing sections just by dragging and dropping the readymade section elements of your choice!


= A bulk number of addons =

To design your site with different elements like texts, titles, contact areas, feature boxes, pricing tables, images, icons, buttons, and many more, we have a rich collection of addons in Page Builder by AZEXO. All of the addons are described at the bottom of this page. You can simply drag & drop the addons on web pages then modify their look and feel.


= It’s FREE, get it at no cost =

Page Builder by AZEXO comes at FREE of cost. Use this WordPress page builder on your website for free. Advanced features like predesigned templates, ready blocks, library system, device-wise responsive control, and a bulk number of addons don’t usually come at free. Utilize all of these cutting-edge features with many other functionalities.


= WordPress Widget Support =

Alongside using all of the exclusive elements of Page Builder by AZEXO, you can also place the WordPress widgets on the site with this page building tool. Page Builder by AZEXO keeps the door open for every possible opportunity for a successful web presence.


= Multilingual Ready =

Having websites in any language is no more an issue as Page Builder by AZEXO has multilingual support. Reach global audience natively.


= Beautifully Designed Shape Dividers =

Bringing a different look to your website is easier with our Shape Divider. There are plenty of built-in shapes in Page Builder by AZEXO to design different sections of your web pages.



= Documentation =

- [Video Tutorials](https://www.youtube.com/playlist?list=PLgb-qaKNfugFNm2gRvl1CsSinlMqRN4cH)
- [How to make elements and sections for builder](http://azexo.com/builder-documentation)
                                       

== Installation ==

1. Upload the `azexo_html` folder to your plugins directory (e.g. `/wp-content/plugins/`)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Follow the instructions


== Frequently Asked Questions ==

= Can I use Page Builder with my existing WordPress theme? =

Sure, you can use your existing WordPress theme with Page Builder by AZEXO.

= Is Page Builder by AZEXO free? =

Yes, it is free and always will be. Also, there is a [Pro version](https://codecanyon.net/item/azexo-html-customizer/16350601) with advanced features.

= Is Page Builder by AZEXO compatible with Custom Post Types? =

Yes, it is compatible with Custom Post Types. You have to checkmark the post types on Page Builder by AZEXO settings.

= How to reduce AZEXO Library size =

- Remove not needed folders wp-content/plugins/azh_extension/azh/[PROJECT-NAME]
- Remove correspond images wp-content/plugins/azh_extension/azh/images/[PROJECT-NAME]
- If you do not plan to add new sections/elements into your site - you can remove all folders inside wp-content/plugins/azh_extension/azh


== Changelog ==

= 1.27 =
* Initial Release
